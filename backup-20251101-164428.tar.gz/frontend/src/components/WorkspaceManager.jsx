import { useState } from 'react'

export default function WorkspaceManager({ onClose, onWorkspaceAdded }) {
  const [path, setPath] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const handleBrowse = async () => {
    if (window.electronAPI && window.electronAPI.dialog) {
      const result = await window.electronAPI.dialog.showOpenDialog({
        properties: ['openDirectory']
      })
      
      if (result && !result.canceled && result.filePaths && result.filePaths.length > 0) {
        setPath(result.filePaths[0])
      }
    } else {
      // Fallback: prompt
      const input = prompt('Enter workspace path:')
      if (input) {
        setPath(input)
      }
    }
  }

  const handleAdd = async () => {
    if (!path.trim()) {
      setError('Please enter a workspace path')
      return
    }

    setLoading(true)
    setError(null)

    try {
      if (window.electronAPI) {
        const workspace = await window.electronAPI.workspace.add(path)
        if (workspace) {
          // Success - workspace added or already exists (which is fine)
          onWorkspaceAdded()
          setPath('') // Clear path
        }
      }
    } catch (err) {
      // Show user-friendly error message
      const errorMsg = err.message || 'Failed to add workspace'
      if (errorMsg.includes('already exists')) {
        setError('This workspace is already added. It will be shown in the list.')
        // Still refresh - the workspace exists
        setTimeout(() => {
          onWorkspaceAdded()
          setPath('')
        }, 1500)
      } else {
        setError(errorMsg)
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
      <div className="bg-cursor-bg-secondary rounded-lg border border-cursor-border shadow-xl p-6 w-full max-w-md">
        <h2 className="text-xl font-semibold mb-4 text-cursor-text-primary">Add Workspace</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-cursor-text-secondary mb-2">
              Workspace Path
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={path}
                onChange={(e) => setPath(e.target.value)}
                placeholder="/path/to/workspace"
                className="flex-1 bg-cursor-bg-primary border border-cursor-border text-cursor-text-primary rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-cursor-accent"
              />
              <button
                onClick={handleBrowse}
                className="px-4 py-2 bg-cursor-bg-tertiary hover:bg-cursor-hover text-cursor-text-primary rounded text-sm font-medium transition-colors"
              >
                Browse
              </button>
            </div>
          </div>

          {error && (
            <div className="bg-cursor-error bg-opacity-20 border border-cursor-error text-cursor-error px-4 py-3 rounded">
              {error}
            </div>
          )}

          <div className="flex justify-end gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-cursor-border rounded hover:bg-cursor-hover text-cursor-text-primary transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleAdd}
              disabled={loading}
              className="px-4 py-2 bg-cursor-accent text-white rounded hover:bg-cursor-accent-hover disabled:bg-cursor-text-muted transition-colors"
            >
              {loading ? 'Adding...' : 'Add Workspace'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
