import { useState, useEffect, useCallback } from 'react'
import CodeViewer from './CodeViewer'
import { electronAPI } from '../services/ipc'

// Browser-compatible path utilities
const basename = (path) => {
  return path.split(/[/\\]/).pop() || path
}

export default function ReviewPanel({ filePath, review: initialReview }) {
  const [review, setReview] = useState(initialReview)
  const [loading, setLoading] = useState(!initialReview)
  const [highlightedLine, setHighlightedLine] = useState(null)
  const [codeContent, setCodeContent] = useState(initialReview?.codeContent || '')
  const [error, setError] = useState(null)

  const loadReview = useCallback(async () => {
    if (window.electronAPI) {
      setLoading(true)
      setError(null)
      try {
        console.log('Loading review for:', filePath)
        const rev = await window.electronAPI.file.getReview(filePath)
        console.log('Review loaded:', rev)
        if (rev) {
          setReview(rev)
          setCodeContent(rev.codeContent || '')
        } else {
          setError('No review found for this file. The file may not have been reviewed yet.')
        }
      } catch (err) {
        console.error('Failed to load review:', err)
        setError('Failed to load review: ' + (err.message || err))
      } finally {
        setLoading(false)
      }
    } else {
      setError('Electron API not available')
      setLoading(false)
    }
  }, [filePath])

  useEffect(() => {
    console.log('ReviewPanel useEffect:', { filePath, initialReview, hasReview: !!review })
    if (initialReview) {
      setReview(initialReview)
      setCodeContent(initialReview.codeContent || '')
      setLoading(false)
    } else if (!review && filePath && window.electronAPI) {
      console.log('No initial review, loading...')
      loadReview()
    }
  }, [filePath, initialReview, review, loadReview])

  const handleCodeChange = async (newCode) => {
    setCodeContent(newCode)
    // Save to file if API available
    if (window.electronAPI && window.electronAPI.file?.saveFile) {
      try {
        await window.electronAPI.file.saveFile(filePath, newCode)
      } catch (err) {
        console.error('Failed to save file:', err)
      }
    }
  }


  // Get icon for category (Cursor-style symbols)
  const getCategoryIcon = (category) => {
    switch (category) {
      case 'security': return '◉'
      case 'performance': return '▲'
      case 'quality': return '•'
      case 'best-practices': return '✓'
      case 'bug': return '!'
      case 'architecture': return '▸'
      default: return '•'
    }
  }

  // Filter findings to only show security/performance related ones
  // Also filter out syntax errors and invalid findings
  const securityAndPerformanceFindings = review?.findings?.filter(f => {
    // Must be security or performance category
    if (f.category !== 'security' && f.category !== 'performance') return false;
    
    // Skip if message or suggestion mentions syntax errors
    const messageLower = (f.message || '').toLowerCase();
    const suggestionLower = (f.suggestion || '').toLowerCase();
    if (messageLower.includes('syntax error') || messageLower.includes('fix the syntax') ||
        suggestionLower.includes('syntax error') || suggestionLower.includes('fix the syntax') ||
        messageLower.includes('compiler error') || messageLower.includes('missing semicolon') ||
        messageLower.includes('missing bracket') || messageLower.includes('missing brace')) {
      return false;
    }
    
    return true;
  }) || []

  // Debug: log findings
  useEffect(() => {
    console.log('=== ReviewPanel Debug ===')
    console.log('Review exists:', !!review)
    console.log('Review status:', review?.status)
    console.log('Total findings:', review?.findings?.length || 0)
    console.log('All findings:', review?.findings)
    console.log('Security/Performance findings after filter:', securityAndPerformanceFindings.length)
    console.log('Security/Performance findings details:', securityAndPerformanceFindings)
    console.log('Review text:', review?.review?.substring(0, 500))
    console.log('========================')
  }, [review, securityAndPerformanceFindings])

  // Format review text to be more intuitive and readable
  // Filters out syntax errors and "N/A" line numbers
  const formatReviewText = (reviewText) => {
    if (!reviewText) return ''
    
    // Escape HTML to prevent XSS
    const escapeHtml = (text) => {
      const div = document.createElement('div')
      div.textContent = text
      return div.innerHTML
    }
    
    // First, remove sections with "N/A" line numbers or syntax errors
    const lines = reviewText.split('\n')
    const filteredLines = []
    let skipSection = false
    let currentSectionHeader = null
    
    lines.forEach((line, index) => {
      const trimmed = line.trim()
      const lowerTrimmed = trimmed.toLowerCase()
      
      // Detect section headers
      if (trimmed.match(/^(Security|Performance)\s+(Vulnerabilities|Issues)[:\-]/i)) {
        currentSectionHeader = trimmed
        // Don't add header yet, wait to see if section has valid content
        return
      }
      
      // Check if this line starts a section with N/A or syntax error
      if (trimmed.match(/^Line\s+(number[:\-]\s*)?N\/A/i) || 
          lowerTrimmed.includes('as this is a syntax error') ||
          lowerTrimmed.includes('line number: n/a')) {
        skipSection = true
        currentSectionHeader = null // Don't keep header if section is invalid
        return
      }
      
      // Check if this line contains syntax error mentions
      if (lowerTrimmed.includes('syntax error') && 
          (lowerTrimmed.includes('fix the syntax') || lowerTrimmed.includes('suggestion:'))) {
        skipSection = true
        currentSectionHeader = null
        return
      }
      
      // Stop skipping when we hit a new valid section
      if (skipSection) {
        if (trimmed.match(/^Line\s+\d+/i)) {
          // Valid line number found, stop skipping
          skipSection = false
          currentSectionHeader = null
        } else if (!trimmed) {
          // Empty line, might be section break
          skipSection = false
          currentSectionHeader = null
        } else {
          // Still skipping
          return
        }
      }
      
      // Skip lines that mention syntax errors in suggestions
      if (lowerTrimmed.includes('suggestion') && 
          (lowerTrimmed.includes('fix the syntax error') || lowerTrimmed.includes('syntax error'))) {
        return
      }
      
      // Only add section header if we're not skipping and we have valid content
      if (currentSectionHeader && trimmed.match(/^Line\s+\d+/i)) {
        filteredLines.push(currentSectionHeader)
        currentSectionHeader = null
      }
      
      filteredLines.push(line)
    })
    
    // Now format the filtered lines
    const formatted = []
    let inFinding = false
    
    filteredLines.forEach((line) => {
      const trimmed = line.trim()
      
      if (!trimmed) {
        if (inFinding) {
          formatted.push('</div>')
          inFinding = false
        }
        return
      }
      
      // Detect numbered findings (1. **Title**)
      if (trimmed.match(/^\d+\.\s*\*\*/)) {
        const titleMatch = trimmed.match(/^\d+\.\s*\*\*([^*]+)\*\*/)
        if (titleMatch) {
          if (inFinding) formatted.push('</div>')
          inFinding = true
          formatted.push(`<div class="mb-2 p-2 bg-cursor-bg-secondary rounded-lg border-l-4 border-cursor-accent shadow-lg break-words overflow-wrap-anywhere">`)
          formatted.push(`<h4 class="text-xs font-bold text-cursor-accent mb-1 break-words">${escapeHtml(titleMatch[1])}</h4>`)
        }
      }
      // Detect line numbers (findings) - both "Line X:" and "Line Number: X" formats
      else if (trimmed.match(/^Line\s+(Number\s*:?\s*)?\d+/i)) {
        const lineNumMatch = trimmed.match(/Line\s+(?:Number\s*:?\s*)?(\d+)/i)
        const lineNum = lineNumMatch?.[1] || ''
        // Only process if it's a valid number
        if (lineNum && !isNaN(parseInt(lineNum)) && parseInt(lineNum) > 0) {
          if (!inFinding) {
            inFinding = true
            formatted.push(`<div class="mb-2 p-2 bg-cursor-bg-secondary rounded-lg border-l-4 border-cursor-accent shadow-sm break-words overflow-wrap-anywhere">`)
          }
          formatted.push(`<div class="flex items-center gap-2 mb-1 break-words"><span class="font-mono text-xs font-semibold text-cursor-accent break-words">Line ${escapeHtml(lineNum)}</span>`)
        }
      }
      // Detect severity markers - both "[severity]" and "Severity: severity" formats
      else if (trimmed.match(/Severity[:\-]\s*(critical|high|medium|low)/i) && inFinding) {
        const severityMatch = trimmed.match(/Severity[:\-]\s*(critical|high|medium|low)/i)
        const severity = severityMatch?.[1]?.toLowerCase() || 'medium'
        const severityColors = {
          critical: 'text-critical bg-critical-bg border-critical border-2',
          high: 'text-high bg-high-bg border-high border-2',
          medium: 'text-medium bg-medium-bg border-medium border-2',
          low: 'text-low bg-low-bg border-low border-2'
        }
        formatted.push(`<span class="px-2 py-1 rounded-lg text-xs font-bold shadow-sm ${severityColors[severity] || 'text-cursor-text-muted bg-cursor-bg-tertiary'}">${severity.toUpperCase()}</span>`)
        if (!trimmed.includes('Category')) {
          formatted.push('</div>')
        }
      }
      else if (trimmed.match(/\[(critical|high|medium|low)\]/i) && inFinding) {
        const severity = trimmed.match(/\[(critical|high|medium|low)\]/i)?.[1] || 'medium'
        const severityColors = {
          critical: 'text-critical bg-critical-bg border-critical border-2',
          high: 'text-high bg-high-bg border-high border-2',
          medium: 'text-medium bg-medium-bg border-medium border-2',
          low: 'text-low bg-low-bg border-low border-2'
        }
        formatted.push(`<span class="px-2 py-1 rounded-lg text-xs font-bold shadow-sm ${severityColors[severity] || 'text-cursor-text-muted bg-cursor-bg-tertiary'}">${severity.toUpperCase()}</span></div>`)
      }
      // Check if it's an impact
      else if (trimmed.match(/^Impact[:\-]/i) && inFinding) {
        const impactText = trimmed.replace(/^Impact[:\-]\s*/i, '')
        formatted.push(`<div class="mt-2 p-2 bg-critical-bg rounded-lg border-2 border-critical border-opacity-30 shadow-sm"><p class="text-xs font-bold text-critical mb-1 uppercase tracking-wide">Impact</p><p class="text-xs text-cursor-text-primary leading-relaxed break-words whitespace-normal">${escapeHtml(impactText)}</p></div>`)
      }
      // Check if it's a suggestion
      else if (trimmed.match(/^Suggestion[:\-]/i) && inFinding) {
        const suggestionText = trimmed.replace(/^Suggestion[:\-]\s*/i, '')
        // Skip if suggestion mentions syntax errors
        if (!suggestionText.toLowerCase().includes('syntax error') && 
            !suggestionText.toLowerCase().includes('fix the syntax')) {
          formatted.push(`<div class="mt-2 p-2 bg-low-bg/30 rounded-lg border-2 border-low border-opacity-30 shadow-sm"><p class="text-xs font-bold text-low mb-1 uppercase tracking-wide">Suggestion</p><p class="text-xs text-cursor-text-primary leading-relaxed break-words whitespace-normal">${escapeHtml(suggestionText)}</p></div>`)
        }
      }
      // Detect category
      else if (trimmed.match(/^Category[:\-]/i) && inFinding) {
        const categoryText = trimmed.replace(/^Category[:\-]\s*/i, '')
        formatted.push(`<span class="px-2 py-1 rounded text-xs font-medium bg-cursor-bg-tertiary text-cursor-text-primary capitalize ml-2">${escapeHtml(categoryText)}</span></div>`)
      }
      // Regular content - show headers and content
      else if (trimmed.length > 0 && 
               !trimmed.toLowerCase().includes('syntax error') &&
               !trimmed.toLowerCase().includes('n/a')) {
        // Check if it's a section header
        if (trimmed.match(/^(Security|Performance)\s+(Vulnerabilities|Issues|Analysis)/i)) {
          formatted.push(`<h3 class="text-xs font-semibold mb-2 mt-3 text-cursor-text-secondary uppercase tracking-wide">${escapeHtml(trimmed)}</h3>`)
        } else if (inFinding) {
          formatted.push(`<p class="text-xs text-cursor-text-primary leading-relaxed mb-2 break-words whitespace-normal">${escapeHtml(trimmed)}</p>`)
        } else {
          // Show content even if not in a finding (for section headers, etc.)
          formatted.push(`<p class="text-xs text-cursor-text-primary leading-relaxed mb-2 break-words whitespace-normal">${escapeHtml(trimmed)}</p>`)
        }
      }
    })
    
    if (inFinding) formatted.push('</div>')
    
    return formatted.join('')
  }

  // Count findings by category (only security/performance)
  const findingsByCategory = securityAndPerformanceFindings.reduce((acc, finding) => {
    const cat = finding.category || 'quality'
    acc[cat] = (acc[cat] || 0) + 1
    return acc
  }, {})

  // Generate user-friendly summary
  const generateSummary = () => {
    if (!review || !securityAndPerformanceFindings || securityAndPerformanceFindings.length === 0) {
      // Check if review text exists but was filtered out
      const hasFilteredContent = review?.review && 
        (review.review.toLowerCase().includes('security') || review.review.toLowerCase().includes('performance')) &&
        securityAndPerformanceFindings.length === 0;
      
      return {
        title: 'No Security or Performance Issues',
        message: hasFilteredContent 
          ? 'Syntax errors and style issues were filtered out. No security vulnerabilities or performance issues identified.'
          : 'No security vulnerabilities or performance issues identified.',
        icon: '✓'
      }
    }

    const critical = securityAndPerformanceFindings.filter(f => f.severity === 'critical').length
    const high = securityAndPerformanceFindings.filter(f => f.severity === 'high').length
    const medium = securityAndPerformanceFindings.filter(f => f.severity === 'medium').length
    const low = securityAndPerformanceFindings.filter(f => f.severity === 'low').length

    const categories = {}
    securityAndPerformanceFindings.forEach(f => {
      const cat = f.category || 'quality'
      categories[cat] = (categories[cat] || 0) + 1
    })

    let title = 'Security & Performance Review'
    let message = `Found ${securityAndPerformanceFindings.length} security or performance issue${securityAndPerformanceFindings.length !== 1 ? 's' : ''}`
    let icon = '●'

    if (critical > 0) {
      title = 'Critical Security/Performance Issues'
      message = `${critical} critical issue${critical !== 1 ? 's' : ''} need${critical === 1 ? 's' : ''} immediate attention`
      icon = '⚠'
    } else if (high > 0) {
      title = 'Important Security/Performance Issues'
      message = `${high} high-priority issue${high !== 1 ? 's' : ''} found`
      icon = '▲'
    } else if (medium > 0) {
      title = 'Security/Performance Improvements'
      message = `${medium} improvement${medium !== 1 ? 's' : ''} recommended`
      icon = '•'
    } else {
      title = 'Minor Security/Performance Suggestions'
      message = `${low} minor suggestion${low !== 1 ? 's' : ''} for optimization`
      icon = '○'
    }

    return { title, message, icon, critical, high, medium, low, categories }
  }

  const summary = generateSummary()
  
  console.log('Summary generated:', summary)
  console.log('Will show summary section:', true)

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-cursor-bg-primary">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cursor-accent mx-auto mb-4"></div>
          <p className="text-cursor-text-primary">Analyzing code...</p>
          <p className="text-xs text-cursor-text-muted mt-2">{filePath}</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex-1 flex items-center justify-center bg-cursor-bg-primary">
        <div className="text-center p-8 bg-cursor-bg-secondary rounded-lg border border-cursor-border shadow-lg max-w-md">
          <div className="text-2xl mb-4 text-cursor-error">⚠</div>
          <h2 className="text-base font-semibold text-cursor-error mb-2">Error</h2>
          <p className="text-sm text-cursor-text-primary mb-4">{error}</p>
          <button
            onClick={loadReview}
            className="px-4 py-2 bg-cursor-accent text-white rounded hover:bg-cursor-accent-hover transition-colors text-sm"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  if (!review) {
    return (
      <div className="flex-1 flex items-center justify-center bg-cursor-bg-primary">
        <div className="text-center p-8 bg-cursor-bg-secondary rounded-lg border border-cursor-border shadow-lg max-w-md">
          <div className="text-2xl mb-4 text-cursor-text-secondary">▸</div>
          <h2 className="text-base font-semibold text-cursor-text-primary mb-2">No Review Available</h2>
          <p className="text-sm text-cursor-text-secondary mb-4">
            This file hasn't been reviewed yet. Save the file to trigger an automatic review.
          </p>
          <p className="text-xs text-cursor-text-muted">{filePath}</p>
        </div>
      </div>
    )
  }

  // Show processing state if review is still being generated
  if (review.status === 'processing') {
    return (
      <div className="flex-1 flex items-center justify-center bg-cursor-bg-primary">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cursor-accent mx-auto mb-4"></div>
          <p className="text-cursor-text-primary">Analyzing code for security and performance issues...</p>
          <p className="text-xs text-cursor-text-muted mt-2">{filePath}</p>
          <p className="text-xs text-cursor-text-muted mt-1">This may take 1-3 minutes</p>
        </div>
      </div>
    )
  }

  // Show error state if review failed
  if (review.status === 'failed') {
    return (
      <div className="flex-1 flex items-center justify-center bg-cursor-bg-primary">
        <div className="text-center p-8 bg-cursor-bg-secondary rounded-lg border border-cursor-border shadow-lg max-w-md">
          <div className="text-2xl mb-4 text-cursor-error">✗</div>
          <h2 className="text-base font-semibold text-cursor-error mb-2">Review Failed</h2>
          <p className="text-sm text-cursor-text-primary mb-4">
            {review.error || 'Failed to generate code review. Please check your Ollama service and try again.'}
          </p>
          <button
            onClick={loadReview}
            className="px-4 py-2 bg-cursor-accent text-white rounded hover:bg-cursor-accent-hover transition-colors text-sm"
          >
            Retry Review
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-cursor-bg-primary">
      {/* Header */}
      <div className="bg-cursor-bg-secondary border-b border-cursor-border p-3">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-base font-semibold text-cursor-text-primary">{basename(filePath)}</h2>
            <p className="text-xs text-cursor-text-secondary mt-1">
              Language: <span className="font-medium text-cursor-text-primary">{review.language}</span> | 
              Status: <span className={`font-medium ${
                review.status === 'completed' ? 'text-cursor-success' : 
                review.status === 'failed' ? 'text-cursor-error' : 
                'text-cursor-warning'
              }`}>{review.status}</span>
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-cursor-text-secondary">
              {review.updatedAt ? new Date(review.updatedAt).toLocaleString() : 'Just now'}
            </p>
            {securityAndPerformanceFindings && securityAndPerformanceFindings.length > 0 && (
              <p className="text-xs text-cursor-text-muted mt-1">
                {securityAndPerformanceFindings.length} issue{securityAndPerformanceFindings.length !== 1 ? 's' : ''}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {/* User-Friendly Summary - Always show */}
        <div className={`rounded-lg shadow-lg p-3 mb-3 border ${
          summary.critical > 0 ? 'bg-critical-bg border-critical/40' :
          summary.high > 0 ? 'bg-high-bg border-high/40' :
          summary.medium > 0 ? 'bg-medium-bg border-medium/40' :
          summary.low > 0 ? 'bg-low-bg border-low/40' :
          'bg-green-500/10 border-green-500/40'
        }`}>
          <div className="flex items-start gap-2">
            <div className={`text-lg mt-0.5 ${
              summary.critical > 0 ? 'text-critical' :
              summary.high > 0 ? 'text-high' :
              summary.medium > 0 ? 'text-medium' :
              summary.low > 0 ? 'text-low' :
              'text-green-400'
            }`}>{summary.icon}</div>
            <div className="flex-1">
              <h3 className={`text-xs font-bold mb-1 ${
                summary.critical > 0 ? 'text-critical' :
                summary.high > 0 ? 'text-high' :
                summary.medium > 0 ? 'text-medium' :
                summary.low > 0 ? 'text-low' :
                'text-green-400'
              }`}>{summary.title}</h3>
              <p className="text-xs text-cursor-text-secondary mb-2">{summary.message}</p>
              {securityAndPerformanceFindings && securityAndPerformanceFindings.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {summary.critical > 0 && (
                    <div className="bg-critical-bg border border-critical/50 rounded-lg px-2 py-1 shadow-sm">
                      <span className="text-critical font-bold text-xs">{summary.critical}</span>
                      <span className="text-critical text-xs ml-1 font-semibold">Critical</span>
                    </div>
                  )}
                  {summary.high > 0 && (
                    <div className="bg-high-bg border border-high/50 rounded-lg px-2 py-1 shadow-sm">
                      <span className="text-high font-bold text-xs">{summary.high}</span>
                      <span className="text-high text-xs ml-1 font-semibold">High</span>
                    </div>
                  )}
                  {summary.medium > 0 && (
                    <div className="bg-medium-bg border border-medium/50 rounded-lg px-2 py-1 shadow-sm">
                      <span className="text-medium font-bold text-xs">{summary.medium}</span>
                      <span className="text-medium text-xs ml-1 font-semibold">Medium</span>
                    </div>
                  )}
                  {summary.low > 0 && (
                    <div className="bg-low-bg border border-low/50 rounded-lg px-2 py-1 shadow-sm">
                      <span className="text-low font-bold text-xs">{summary.low}</span>
                      <span className="text-low text-xs ml-1 font-semibold">Low</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Review Summary - Focus on Security/Performance */}
        {review.review && review.review.trim().length > 0 && (
          <div className="bg-cursor-bg-secondary rounded-lg shadow-lg p-3 mb-3 border-2 border-cursor-accent border-opacity-30">
            <h3 className="text-xs font-semibold mb-2 flex items-center text-cursor-accent uppercase tracking-wide">
              <span className="mr-2 text-cursor-accent">●</span>
              Security & Performance Analysis
            </h3>
            <div className="bg-gradient-to-br from-cursor-bg-primary to-cursor-bg-tertiary rounded-lg p-3 border border-cursor-accent border-opacity-20 overflow-hidden">
              <p className="text-sm text-cursor-text-primary leading-relaxed break-words font-medium">
                {review.review.trim()}
              </p>
            </div>
          </div>
        )}

        {/* Category Summary */}
        {Object.keys(findingsByCategory).length > 0 && (
          <div className="bg-cursor-bg-secondary rounded-lg shadow-lg p-3 mb-4 border-2 border-cursor-accent border-opacity-30">
            <h3 className="text-xs font-semibold text-cursor-accent mb-2 uppercase tracking-wide">Insights by Category</h3>
            <div className="flex flex-wrap gap-2">
              {Object.entries(findingsByCategory).map(([category, count]) => {
                const isSecurity = category === 'security';
                const isPerformance = category === 'performance';
                return (
                  <div 
                    key={category} 
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border-2 cursor-pointer transition-all hover:scale-105 shadow-sm ${
                      isSecurity 
                        ? 'bg-security-bg border-security text-security hover:bg-security-bg/50' 
                        : isPerformance
                        ? 'bg-performance-bg border-performance text-performance hover:bg-performance-bg/50'
                        : 'bg-cursor-bg-tertiary border-cursor-border hover:bg-cursor-hover text-cursor-text-primary'
                    }`}
                    onClick={() => {
                      const firstFinding = securityAndPerformanceFindings.find(f => (f.category || 'quality') === category)
                      if (firstFinding?.lineNumber) {
                        setHighlightedLine(firstFinding.lineNumber)
                        setTimeout(() => setHighlightedLine(null), 3000)
                      }
                    }}
                  >
                    <span className="text-sm">{getCategoryIcon(category)}</span>
                    <span className="text-xs font-semibold capitalize">{category.replace('-', ' ')}</span>
                    <span className={`text-xs font-bold ${
                      isSecurity ? 'text-security' : isPerformance ? 'text-performance' : 'text-cursor-text-muted'
                    }`}>({count})</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Findings - Only Security/Performance */}
        {securityAndPerformanceFindings && securityAndPerformanceFindings.length > 0 && (
          <div className="bg-cursor-bg-secondary rounded-lg shadow-lg p-3 mb-3 border-2 border-cursor-accent border-opacity-30">
            <div className="flex items-center justify-between mb-2 pb-2 border-b-2 border-cursor-accent border-opacity-30">
              <h3 className="text-xs font-semibold flex items-center text-cursor-accent uppercase tracking-wide">
                <span className="mr-2 text-cursor-accent">●</span>
                Security & Performance Issues ({securityAndPerformanceFindings.length})
              </h3>
            </div>
            <div className="space-y-2">
              {securityAndPerformanceFindings.map((finding, index) => (
                <div
                  key={finding._id || index}
                  className={`border-l-4 rounded-r-lg p-2 shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer ${
                    finding.severity === 'critical'
                      ? 'border-critical bg-critical-bg hover:bg-critical-bg/60'
                      : finding.severity === 'high'
                      ? 'border-high bg-high-bg hover:bg-high-bg/60'
                      : finding.severity === 'medium'
                      ? 'border-medium bg-medium-bg hover:bg-medium-bg/60'
                      : 'border-low bg-low-bg hover:bg-low-bg/60'
                  }`}
                  onClick={() => {
                    if (finding.lineNumber) {
                      setHighlightedLine(finding.lineNumber)
                      // Scroll to code viewer
                      setTimeout(() => {
                        const codeViewer = document.querySelector('[data-code-viewer]')
                        if (codeViewer) {
                          codeViewer.scrollIntoView({ behavior: 'smooth', block: 'start' })
                        }
                      }, 100)
                    }
                  }}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {finding.lineNumber && (
                        <span className={`font-mono text-xs font-bold px-2 py-1 rounded-lg border shadow-sm ${
                          finding.severity === 'critical'
                            ? 'bg-critical-bg border-critical/50 text-critical'
                            : finding.severity === 'high'
                            ? 'bg-high-bg border-high/50 text-high'
                            : finding.severity === 'medium'
                            ? 'bg-medium-bg border-medium/50 text-medium'
                            : 'bg-low-bg border-low/50 text-low'
                        }`}>
                          L{finding.lineNumber}
                        </span>
                      )}
                      <span className={`text-xs px-2 py-1 rounded-lg font-bold border shadow-sm ${
                        finding.severity === 'critical'
                          ? 'bg-critical-bg border-critical/50 text-critical'
                          : finding.severity === 'high'
                          ? 'bg-high-bg border-high/50 text-high'
                          : finding.severity === 'medium'
                          ? 'bg-medium-bg border-medium/50 text-medium'
                          : 'bg-low-bg border-low/50 text-low'
                      }`}>
                        {finding.severity}
                      </span>
                      {finding.category && (
                        <span className={`text-xs px-2 py-1 rounded-lg font-semibold border shadow-sm ${
                          finding.category === 'security'
                            ? 'bg-security-bg border-security/50 text-security'
                            : finding.category === 'performance'
                            ? 'bg-performance-bg border-performance/50 text-performance'
                            : 'bg-cursor-bg-tertiary border-cursor-border text-cursor-text-primary'
                        } flex items-center gap-1`}>
                          <span className="text-xs">{getCategoryIcon(finding.category)}</span>
                          {finding.category.replace('-', ' ')}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  <div className="mb-2">
                    <p className="text-xs text-cursor-text-primary font-medium leading-relaxed mb-1.5 break-words">{finding.message}</p>
                    
                    {finding.impact && (
                      <div className={`mt-1.5 p-2 rounded-lg border shadow-sm ${
                        finding.severity === 'critical'
                          ? 'bg-critical-bg/50 border-critical/30'
                          : finding.severity === 'high'
                          ? 'bg-high-bg/50 border-high/30'
                          : 'bg-medium-bg/50 border-medium/30'
                      }`}>
                        <p className={`text-xs font-bold mb-1 uppercase tracking-wide ${
                          finding.severity === 'critical'
                            ? 'text-critical'
                            : finding.severity === 'high'
                            ? 'text-high'
                            : 'text-medium'
                        }`}>Impact</p>
                        <p className="text-xs text-cursor-text-primary leading-relaxed break-words whitespace-normal">{finding.impact}</p>
                      </div>
                    )}
                    
                    {finding.suggestion && (
                      <div className={`mt-1.5 p-2 rounded-lg border shadow-sm ${
                        finding.severity === 'critical'
                          ? 'bg-critical-bg/40 border-critical/30'
                          : finding.severity === 'high'
                          ? 'bg-high-bg/40 border-high/30'
                          : finding.severity === 'medium'
                          ? 'bg-medium-bg/40 border-medium/30'
                          : 'bg-low-bg/40 border-low/30'
                      }`}>
                        <p className={`text-xs font-bold mb-1 uppercase tracking-wide ${
                          finding.severity === 'critical'
                            ? 'text-critical'
                            : finding.severity === 'high'
                            ? 'text-high'
                            : finding.severity === 'medium'
                            ? 'text-medium'
                            : 'text-low'
                        }`}>Recommendation</p>
                        <p className="text-xs text-cursor-text-primary leading-relaxed break-words whitespace-normal mb-1.5">{finding.suggestion}</p>
                        {finding.lineNumber && (
                          <p className={`text-xs mt-2 font-semibold ${
                            finding.severity === 'critical'
                              ? 'text-critical'
                              : finding.severity === 'high'
                              ? 'text-high'
                              : finding.severity === 'medium'
                              ? 'text-medium'
                              : 'text-low'
                          }`}>
                            Click to highlight line {finding.lineNumber} in code viewer
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                  
                  {finding.guidelines && finding.guidelines.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-cursor-border">
                      <span className="text-xs text-cursor-text-muted">Guidelines: </span>
                      {finding.guidelines.map((guideline, idx) => (
                        <span key={idx} className="text-xs bg-cursor-bg-tertiary text-cursor-accent px-1.5 py-0.5 rounded mr-1 border border-cursor-accent border-opacity-30">
                          {guideline}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
        
        {(!securityAndPerformanceFindings || securityAndPerformanceFindings.length === 0) && (
          <div className="bg-cursor-bg-secondary border border-cursor-success rounded-lg p-3 mb-4 text-center">
            <div className="text-xs mb-1.5 text-cursor-success">✓</div>
            <p className="text-cursor-success font-medium text-xs">No Security or Performance Issues</p>
            <p className="text-cursor-text-secondary text-xs mt-1">
              {review.findings && review.findings.length > 0 
                ? 'Syntax errors and style issues were filtered out. No security vulnerabilities or performance issues identified in this file.'
                : 'No security vulnerabilities or performance issues identified in this file.'}
            </p>
          </div>
        )}

        {/* Code Viewer */}
        <div className="bg-cursor-bg-secondary rounded-lg shadow-sm border border-cursor-border" data-code-viewer>
          <h3 className="text-xs font-semibold p-3 border-b border-cursor-border flex items-center text-cursor-text-secondary uppercase tracking-wide">
            <span className="mr-2 text-cursor-text-muted">▸</span>
            Source Code
          </h3>
          <div className="h-[500px]">
            <CodeViewer 
              code={codeContent} 
              language={review.language}
              highlightedLines={securityAndPerformanceFindings
                .filter(f => f.lineNumber && typeof f.lineNumber === 'number' && f.lineNumber > 0)
                .map(f => f.lineNumber)
                .concat(highlightedLine ? [highlightedLine] : [])
                .filter((v, i, a) => a.indexOf(v) === i)
                .sort((a, b) => a - b)}
              editable={true}
              onCodeChange={handleCodeChange}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
