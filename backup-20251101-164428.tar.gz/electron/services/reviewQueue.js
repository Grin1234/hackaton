import { EventEmitter } from 'events';
import { readFileSync } from 'fs';
import { join, dirname, extname } from 'path';
import { fileURLToPath } from 'url';
import { ensureMongoConnection } from '../utils/mongodb.js';
import Review from '../models/Review.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = join(__dirname, '../..');

// Import paths for backend services
const ollamaServicePath = join(projectRoot, 'backend/src/services/ollamaService.js');
const codeParserPath = join(projectRoot, 'backend/src/services/codeParser.js');

// Cache for imported modules
let ollamaService = null;
let codeParser = null;

async function loadServices() {
  if (!ollamaService) {
    ollamaService = await import(ollamaServicePath);
  }
  if (!codeParser) {
    codeParser = await import(codeParserPath);
  }
  return { generateCodeReview: ollamaService.generateCodeReview };
}

/**
 * Review Queue Manager - Phase 4
 * Processes code reviews in the background
 */
class ReviewQueue extends EventEmitter {
  constructor() {
    super();
    this.queue = [];
    this.processing = false;
    this.maxConcurrentReviews = 1; // Process one review at a time
    this.currentReview = null;
  }

  /**
   * Add a file to the review queue
   * @param {string} filePath - Full path to the file
   * @param {string} workspacePath - Workspace root path
   */
  async addToQueue(filePath, workspacePath) {
    // Check if file is already in queue
    const existing = this.queue.find(item => item.filePath === filePath);
    if (existing) {
      console.log(`⏭️ File already in queue: ${filePath}`);
      return;
    }

    // Check if file is currently being reviewed
    if (this.currentReview && this.currentReview.filePath === filePath) {
      console.log(`⏳ File currently being reviewed: ${filePath}`);
      return;
    }

    // Check if file is a code file
    const ext = extname(filePath).toLowerCase();
    const codeExtensions = ['.js', '.jsx', '.ts', '.tsx', '.py', '.java', '.cpp', '.c', '.go', '.rs', '.rb', '.php'];
    
    if (!codeExtensions.includes(ext)) {
      console.log(`⏭️ Skipping non-code file: ${filePath}`);
      return;
    }

    const queueItem = {
      filePath,
      workspacePath,
      addedAt: new Date(),
      status: 'pending'
    };

    this.queue.push(queueItem);
    console.log(`📝 Added to review queue: ${filePath} (Queue size: ${this.queue.length})`);
    
    this.emit('queued', queueItem);
    
    // Start processing if not already processing
    if (!this.processing) {
      this.processQueue();
    }
  }

  /**
   * Process the review queue
   */
  async processQueue() {
    if (this.processing || this.queue.length === 0) {
      return;
    }

    this.processing = true;

    while (this.queue.length > 0) {
      const item = this.queue.shift();
      this.currentReview = item;

      try {
        console.log(`🔍 Processing review: ${item.filePath}`);
        this.emit('reviewStarted', item);
        
        await this.reviewFile(item.filePath, item.workspacePath);
        
        console.log(`✅ Review completed: ${item.filePath}`);
        this.emit('reviewCompleted', item);
      } catch (error) {
        console.error(`❌ Review failed for ${item.filePath}:`, error.message);
        this.emit('reviewFailed', item, error);
      } finally {
        this.currentReview = null;
      }
    }

    this.processing = false;
    console.log('✅ Review queue processing complete');
  }

  /**
   * Review a single file
   * @param {string} filePath - Full path to the file
   * @param {string} workspacePath - Workspace root path
   */
  async reviewFile(filePath, workspacePath) {
    await ensureMongoConnection();

    try {
      // Read file content
      const content = readFileSync(filePath, 'utf-8');
      const fileName = filePath.split(/[/\\]/).pop();
      
      // Detect language
      const ext = extname(fileName).toLowerCase();
      const languageMap = {
        '.js': 'javascript', '.jsx': 'javascript',
        '.ts': 'typescript', '.tsx': 'typescript',
        '.py': 'python',
        '.java': 'java',
        '.cpp': 'cpp', '.c': 'c',
        '.go': 'go',
        '.rs': 'rust',
        '.rb': 'ruby',
        '.php': 'php'
      };
      const language = languageMap[ext] || 'text';

      // Check if review already exists for this file
      const existingReview = await Review.findOne({ filePath });
      
      // Create or update review document with 'processing' status
      const reviewData = {
        fileName,
        filePath,
        language,
        codeContent: content,
        status: 'processing',
        incremental: !!existingReview // If review exists, this is incremental
      };

      let review;
      let appliedFindingsMap = new Map();
      
      if (existingReview) {
        // Preserve applied findings when updating review
        if (existingReview.findings) {
          existingReview.findings.forEach(f => {
            if (f.applied) {
              const key = `${f.lineNumber || 'general'}-${f.message}`;
              appliedFindingsMap.set(key, f);
            }
          });
        }
        
        // Update existing review
        Object.assign(existingReview, reviewData);
        review = existingReview;
      } else {
        review = new Review(reviewData);
      }

      await review.save();

      // Generate review using Ollama
      console.log(`🤖 Generating AI review for ${fileName}...`);
      console.log(`   File size: ${content.length} characters`);
      console.log(`   Language: ${language}`);
      console.log(`   ⏳ This may take 1-3 minutes on CPU mode...`);
      
      try {
        const { generateCodeReview } = await loadServices();
        
        // Add progress logging
        console.log(`   Calling Ollama API...`);
        const startTime = Date.now();
        
        const reviewResult = await generateCodeReview(content, language, {
          incremental: !!existingReview
        });
        
        const duration = Date.now() - startTime;
        const seconds = Math.round(duration / 1000);
        console.log(`   ✅ Ollama responded in ${seconds}s`);

        // Preserve applied findings from existing review
        const mergedFindings = (reviewResult.findings || []).map(newFinding => {
          const key = `${newFinding.lineNumber || 'general'}-${newFinding.message}`;
          const appliedFinding = appliedFindingsMap.get(key);
          
          if (appliedFinding) {
            // Preserve applied status
            return {
              ...newFinding,
              applied: true,
              rejected: appliedFinding.rejected || false
            };
          }
          return newFinding;
        });

        // Update review with results
        review.review = reviewResult.review || 'Review generated successfully';
        review.findings = mergedFindings;
        review.status = 'completed';
        review.tokenUsage = reviewResult.tokenUsage || {};
        review.updatedAt = new Date();

        await review.save();

        console.log(`✅ Review saved: ${review.findings.length} findings`);

        // Emit event with review results
        this.emit('reviewReady', {
          review: review.toObject(),
          filePath,
          workspacePath
        });

        return review;
      } catch (ollamaError) {
        // If Ollama fails, save error but don't fail completely
        const errorMsg = ollamaError.message || 'Unknown error';
        review.review = `Error generating review: ${errorMsg}`;
        review.status = 'failed';
        review.error = errorMsg;
        
        // Check if it's a memory error and provide helpful message
        if (errorMsg.includes('memory') || errorMsg.includes('Memory')) {
          review.error = `${errorMsg}\n\n💡 Suggestion: Try using a smaller model (e.g., codellama:7b or codellama:13b) or free up system memory.`;
        }
        
        await review.save();
        
        // Re-throw so it's handled by the queue processor
        throw new Error(`Ollama review failed: ${errorMsg}`);
      }
    } catch (error) {
      // Update review status to failed
      try {
        const existingReview = await Review.findOne({ filePath });
        if (existingReview) {
          existingReview.status = 'failed';
          existingReview.error = error.message;
          await existingReview.save();
        }
      } catch (saveError) {
        console.error('Failed to save error status:', saveError);
      }

      throw error;
    }
  }

  /**
   * Get queue status
   */
  getStatus() {
    return {
      queueSize: this.queue.length,
      processing: this.processing,
      currentReview: this.currentReview ? {
        filePath: this.currentReview.filePath,
        status: this.currentReview.status
      } : null
    };
  }

  /**
   * Clear the queue
   */
  clearQueue() {
    this.queue = [];
    console.log('🧹 Review queue cleared');
  }
}

// Export singleton instance
export const reviewQueue = new ReviewQueue();
