import mongoose from 'mongoose';

// Disable buffering on this model's connection
// This ensures queries fail immediately if not connected
if (mongoose.connection.readyState === 0) {
  mongoose.set('bufferCommands', false);
  mongoose.set('bufferTimeoutMS', 0);
}

const commentSchema = new mongoose.Schema({
  lineNumber: { type: Number, required: true },
  content: { type: String, required: true },
  type: { type: String, enum: ['suggestion', 'warning', 'error', 'info'], default: 'suggestion' },
  replies: [{
    content: String,
    createdAt: { type: Date, default: Date.now }
  }],
  resolved: { type: Boolean, default: false },
  rejected: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

const reviewSchema = new mongoose.Schema({
  fileName: { type: String, required: true },
  filePath: { type: String, required: true },
  language: { type: String, required: true },
  codeContent: { type: String, required: true },
  review: { type: String, required: true },
  findings: [{
    lineNumber: Number,
    severity: { type: String, enum: ['low', 'medium', 'high', 'critical'] },
    category: { type: String, enum: ['security', 'performance', 'style', 'bug', 'documentation', 'architecture', 'linting', 'testing'] },
    message: String,
    suggestion: String,
    effortEstimation: { 
      type: String, 
      enum: ['trivial', 'low', 'medium', 'high'],
      default: 'medium'
    },
    applied: { type: Boolean, default: false },
    rejected: { type: Boolean, default: false },
    guidelines: [String], // Array of guideline names (e.g., 'PEP8', 'Google Style')
    createdAt: { type: Date, default: Date.now }
  }],
  comments: [commentSchema],
  status: { 
    type: String, 
    enum: ['pending', 'processing', 'completed', 'failed'], 
    default: 'pending' 
  },
  incremental: { type: Boolean, default: false },
  tokenUsage: {
    promptTokens: Number,
    completionTokens: Number,
    totalTokens: Number
  },
  error: String,
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

reviewSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

// Use mongoose.models to avoid overwriting existing model
const Review = mongoose.models.Review || mongoose.model('Review', reviewSchema);

export default Review;

