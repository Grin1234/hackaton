import fs from 'fs/promises';
import path from 'path';

/**
 * Parse a code file and extract language and content
 * @param {string} filePath - Path to the code file
 * @param {string} fileName - Original filename
 * @returns {Promise<Object>} Parsed code data
 */
export const parseCodeFile = async (filePath, fileName) => {
  try {
    const content = await fs.readFile(filePath, 'utf-8');
    const language = detectLanguage(fileName, content);
    
    return {
      content: content,
      language: language,
      fileName: fileName,
      filePath: filePath
    };
  } catch (error) {
    throw new Error(`Failed to parse code file: ${error.message}`);
  }
};

/**
 * Detect programming language from filename and content
 */
const detectLanguage = (fileName, content) => {
  const ext = path.extname(fileName).toLowerCase();
  
  const languageMap = {
    '.js': 'javascript',
    '.jsx': 'javascript',
    '.ts': 'typescript',
    '.tsx': 'typescript',
    '.py': 'python',
    '.java': 'java',
    '.cpp': 'cpp',
    '.cc': 'cpp',
    '.cxx': 'cpp',
    '.c': 'c',
    '.go': 'go',
    '.rs': 'rust',
    '.rb': 'ruby',
    '.php': 'php',
    '.md': 'markdown',
    '.html': 'html',
    '.css': 'css',
    '.json': 'json',
    '.xml': 'xml',
    '.yaml': 'yaml',
    '.yml': 'yaml'
  };

  return languageMap[ext] || 'text';
};

/**
 * Extract code changes from git diff
 */
export const parseGitDiff = (diffText) => {
  const changes = [];
  const lines = diffText.split('\n');
  
  let currentFile = null;
  let currentLine = 0;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // Detect file header
    if (line.startsWith('+++') || line.startsWith('---')) {
      if (line.startsWith('+++')) {
        currentFile = line.substring(4).trim();
      }
      continue;
    }
    
    // Detect line numbers
    if (line.startsWith('@@')) {
      const match = line.match(/@@ -(\d+)/);
      if (match) {
        currentLine = parseInt(match[1]);
      }
      continue;
    }
    
    // Detect added/modified lines
    if (line.startsWith('+') && !line.startsWith('+++')) {
      changes.push({
        file: currentFile,
        lineNumber: currentLine,
        type: 'added',
        content: line.substring(1)
      });
      currentLine++;
    } else if (line.startsWith('-') && !line.startsWith('---')) {
      currentLine++;
    } else if (!line.startsWith('@@')) {
      currentLine++;
    }
  }
  
  return changes;
};

